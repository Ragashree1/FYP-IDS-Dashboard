1. Prerequisites
Make sure you have the following installed:
Python 3.x
pip
Java 11 or 17 (required by Logstash and Elasticsearch)
Elasticsearch
Logstash
Filebeat
FastAPI with uvicorn
CICFlowMeter (Python version)

2. Install CICFlowMeter
Clone the repo and install it:
git clone https://github.com/datthinh1801/cicflowmeter.git
cd cicflowmeter
pip install -r requirements.txt
sudo python3 setup.py install

Ensure cicflowmeter is accessible:
which cicflowmeter
If not in PATH, add:
export PATH="$HOME/.local/bin:$PATH"

3. Start Flow Capture with CICFlowMeter
Run in real-time from a network interface (e.g. eth0):
sudo cicflowmeter -i eth0 -c /var/log/flows.csv

- This will generate a CSV of network flow features to /var/log/flows.csv.

4. Next, copy and paste the filebeat.yml file that we have provided 

5. Then, copy and paste the logstash config file that we provided.

6.Then you can start the services for all of them
Start Elasticsearch:
sudo systemctl start elasticsearch

Start Logstash:
sudo systemctl start logstash

Start Filebeat:
sudo systemctl start filebeat

Confirm data is reaching Elasticsearch:
curl -X GET "localhost:9200/cicflowmeter-flows/_search?pretty"