This archive contains the essential configuration files to set up a full Zeek → Filebeat → Logstash → Elasticsearch pipeline:

1. filebeat.yml  
   → Main Filebeat config that ships logs from Zeek to Logstash.


4. networks.cfg (Zeek)
   → Defines the monitored network ranges.

5. node.cfg (Zeek)
   → Defines the Zeek deployment layout (standalone, workers, etc).

6. zeekctl.cfg (Zeek)
   → ZeekCtl settings for managing Zeek processes.
